import express from 'express';

const app = express();
app.use(express.json());
const TOKEN = process.env.BOT_TOKEN;
const ADMIN_CHAT_ID = process.env.ADMIN_CHAT_ID;
const WEBHOOK_SECRET = process.env.WEBHOOK_SECRET;
const PORT = process.env.PORT || 3000;
const sessions = new Map();

if (!TOKEN) console.warn('BOT_TOKEN is not set. Add it in the hosting environment.');
const api = (method, body) => fetch(`https://api.telegram.org/bot${TOKEN}/${method}`, {
  method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(body)
}).then(r => r.json());

const menu = {
  keyboard: [[{ text: '⚽ Bron qilish' }, { text: '💰 Narxlar' }], [{ text: '🕒 Ish vaqti' }, { text: '📍 Manzil' }], [{ text: '📞 Administrator' }]],
  resize_keyboard: true
};
const prices = '💰 OLTIBOY ARENA NARXLARI\n\n1 soat — 90 000 so‘m\n1,5 soat — 135 000 so‘m\n2 soat — 180 000 so‘m';
const address = '📍 Bandixon tumani, Obod Turmush MFY, 5-maktabdan sal uzoqlikda.';
const welcome = `Assalomu alaykum! ⚽\n\nOLTIBOY ARENA botiga xush kelibsiz!\n\n🕒 Ish vaqti: 07:00–00:00\n${address}\n\nQuyidagi menyudan foydalaning.`;
async function send(chatId, text, reply_markup = menu) {
  if (!TOKEN) return;
  return api('sendMessage', { chat_id: chatId, text, reply_markup });
}
async function handleMessage(m) {
  const chatId = m.chat.id;
  const text = (m.text || '').trim();
  if (text === '/start' || text === '⬅️ Menyu') {
    sessions.delete(chatId);
    return send(chatId, welcome);
  }
  if (text === '/myid') return send(chatId, `Sizning Telegram chat ID raqamingiz: ${chatId}\nAdmin sozlamasiga shu raqamni kiriting.`);
  if (text === '💰 Narxlar') return send(chatId, prices);
  if (text === '🕒 Ish vaqti') return send(chatId, '🕒 Har kuni 07:00 dan 00:00 gacha ishlaymiz.');
  if (text === '📍 Manzil') return send(chatId, address);
  if (text === '📞 Administrator') return send(chatId, 'Administrator: @musulmonov010');
  if (text === '⚽ Bron qilish') {
    sessions.set(chatId, { step: 'name', booking: {} });
    return send(chatId, '⚽ Bron qilish uchun ismingizni yozing.', { keyboard: [[{ text: '⬅️ Menyu' }]], resize_keyboard: true });
  }
  const s = sessions.get(chatId);
  if (!s) return send(chatId, 'Buyruqni tushunmadim. Menyudan birini tanlang.');
  if (s.step === 'name') {
    s.booking.name = text; s.step = 'phone';
    return send(chatId, 'Telefon raqamingizni yozing (masalan, +998901234567).');
  }
  if (s.step === 'phone') {
    if (!/^\+?\d[\d ()-]{7,}$/.test(text)) return send(chatId, 'Telefon raqamini to‘g‘ri kiriting. Masalan: +998901234567');
    s.booking.phone = text; s.step = 'date';
    return send(chatId, 'Qaysi sanaga bron qilmoqchisiz? (masalan, 2026-11-05)');
  }
  if (s.step === 'date') {
    if (!/^\d{4}-\d{2}-\d{2}$/.test(text)) return send(chatId, 'Sanani YYYY-MM-DD shaklida kiriting. Masalan: 2026-11-05');
    s.booking.date = text; s.step = 'time';
    return send(chatId, 'Boshlanish vaqtini yozing (07:00 dan 23:00 gacha, masalan 18:00).');
  }
  if (s.step === 'time') {
    const match = /^(\d{2}):(\d{2})$/.exec(text);
    if (!match || +match[1] < 7 || +match[1] > 23 || +match[2] > 59) return send(chatId, 'Vaqtni HH:MM shaklida kiriting. Masalan: 18:00.');
    s.booking.time = text; s.step = 'duration';
    return send(chatId, 'Davomiylikni tanlang:', { keyboard: [[{ text: '1 soat' }, { text: '1,5 soat' }, { text: '2 soat' }], [{ text: '⬅️ Menyu' }]], resize_keyboard: true });
  }
  if (s.step === 'duration') {
    const options = { '1 soat': ['1 soat', '90 000 so‘m'], '1,5 soat': ['1,5 soat', '135 000 so‘m'], '2 soat': ['2 soat', '180 000 so‘m'] };
    if (!options[text]) return send(chatId, 'Iltimos, 1 soat, 1,5 soat yoki 2 soatni tanlang.');
    s.booking.duration = options[text][0]; s.booking.price = options[text][1]; s.booking.userId = chatId;
    const b = s.booking; sessions.delete(chatId);
    const summary = `🆕 YANGI BRON SO‘ROVI\n\nIsm: ${b.name}\nTelefon: ${b.phone}\nSana: ${b.date}\nVaqt: ${b.time}\nDavomiylik: ${b.duration}\nNarx: ${b.price}\nMijoz chat ID: ${b.userId}\n\nHolat: tasdiqlanmagan`;
    if (ADMIN_CHAT_ID) await send(ADMIN_CHAT_ID, summary, { inline_keyboard: [[{ text: '✅ Tasdiqlash', callback_data: `ok:${b.userId}:${b.date}:${b.time}` }, { text: '❌ Rad etish', callback_data: `no:${b.userId}` }]] });
    await send(chatId, '✅ Bron so‘rovingiz yuborildi. Administrator tasdiqlashini kuting. Bu hali tasdiqlangan bron emas.');
    if (!ADMIN_CHAT_ID) await send(chatId, 'Eslatma: administrator chat ID hali serverga sozlanmagan, shu sabab so‘rov adminga yuborilmadi.');
  }
}

app.get('/', (_req, res) => res.send('Oltiboy Arena bot server ishlayapti.'));
app.post('/telegram/webhook', async (req, res) => {
  if (WEBHOOK_SECRET && req.get('X-Telegram-Bot-Api-Secret-Token') !== WEBHOOK_SECRET) return res.sendStatus(403);
  res.sendStatus(200);
  try {
    const u = req.body;
    if (u.message) await handleMessage(u.message);
    if (u.callback_query) {
      const q = u.callback_query;
      await api('answerCallbackQuery', { callback_query_id: q.id });
      const [action, userId, date, time] = (q.data || '').split(':');
      if (action === 'ok') await send(userId, `✅ Bron tasdiqlandi!\nSana: ${date}\nVaqt: ${time}\nIltimos, vaqtida keling.`);
      if (action === 'no') await send(userId, '❌ Afsuski, bron so‘rovingiz rad etildi. Boshqa vaqtni tanlab ko‘ring.');
      if (q.message) await api('editMessageReplyMarkup', { chat_id: q.message.chat.id, message_id: q.message.message_id, reply_markup: { inline_keyboard: [] } });
    }
  } catch (e) { console.error('Webhook handling error:', e); }
});
app.listen(PORT, async () => {
  console.log(`Oltiboy Arena bot server listening on ${PORT}`);
  const base = process.env.RENDER_EXTERNAL_URL;
  if (TOKEN && base) {
    const secret = WEBHOOK_SECRET ? { secret_token: WEBHOOK_SECRET } : {};
    const result = await api('setWebhook', { url: `${base}/telegram/webhook`, ...secret });
    console.log('Webhook setup:', result?.ok ? 'success' : result?.description);
  }
});
