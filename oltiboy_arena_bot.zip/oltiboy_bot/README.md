# Oltiboy Arena Telegram bot (Render)

## What it does
- `/start` menu: booking, prices, hours, address, admin contact.
- Booking collects name, phone, date, time, and duration.
- Sends an unconfirmed request to the configured admin chat and lets admin approve/reject.

## Deploy to Render
1. Create a GitHub repository and upload these files (including `package.json` and `server.js`; do not upload `.env`).
2. In Render choose **New + > Web Service**, connect the repository.
3. Runtime: Node. Build command: `npm install`. Start command: `npm start`.
4. Add environment variables in Render:
   - `BOT_TOKEN`: token from BotFather (keep private).
   - `ADMIN_CHAT_ID`: admin's numeric Telegram chat ID.
   - `WEBHOOK_SECRET`: a long random string (optional but recommended).
5. Deploy. Render sets `RENDER_EXTERNAL_URL`; the app registers its Telegram webhook on startup.
6. Open the bot and send `/start`.

## Find admin chat ID
After deploy, send `/myid` to the bot from the Telegram account that should receive booking requests. Copy the numeric ID from the reply, add it as `ADMIN_CHAT_ID` in Render Environment, then redeploy.

## Important limitations
This starter does not yet prevent overlapping bookings or store bookings in a database. Admin approval/rejection buttons notify the customer but do not create a durable calendar reservation. Add a database and conflict checking before accepting real bookings. SMS notifications are not configured; an SMS provider/API is required.
